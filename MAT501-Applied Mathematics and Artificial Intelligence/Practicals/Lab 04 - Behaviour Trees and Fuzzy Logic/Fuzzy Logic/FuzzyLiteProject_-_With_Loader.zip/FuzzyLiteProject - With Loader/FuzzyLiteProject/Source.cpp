#include <fl/Headers.h>
#include "FlsImporter.h"

using namespace fl;

int main()
{
	Engine* engine = FlsImporter().fromFile("Example.fls");

	while (1)
	{
		std::string foodQuality = "";
		std::cout << "Please enter a food quality score (0-100): ";
		std::cin >> foodQuality;

		std::string serviceQuality = "";
		std::cout << std::endl << "Please enter a service quality score (0, 1.0): ";
		std::cin >> serviceQuality;

		std::stringstream foodStream(foodQuality);
		float foodQualityCrisp = 0.f;
		foodStream >> foodQualityCrisp;

		std::stringstream qualityStream(serviceQuality);
		float serviceQualityCrisp = 0.f;
		qualityStream >> serviceQualityCrisp;

		InputVariable* quality = engine->getInputVariable("quality");
		InputVariable* service = engine->getInputVariable("service");
		OutputVariable* tip = engine->getOutputVariable("tip");

		quality->setValue(foodQualityCrisp);
		service->setValue(serviceQualityCrisp);

		engine->process();

		std::cout << std::endl << std::endl << "quality.input = " << foodQualityCrisp << " && service.input = " << serviceQualityCrisp << std::endl <<
			"\t => steer.output = " << tip->getValue() << std::endl << std::endl;
	}

	delete engine;

	return 0;
}