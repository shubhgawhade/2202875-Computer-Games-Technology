﻿namespace MCTS.Enum
{
    public enum EGameFinalStatus
    {
        GameWon  = 0,

        GameLost = 1,

        GameDraw = 2,
    }
}
