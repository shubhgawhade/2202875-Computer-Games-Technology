﻿namespace MCTS.V2.Interfaces
{
    public interface IPlayer
    { 
        string Name { get; }
    }
}