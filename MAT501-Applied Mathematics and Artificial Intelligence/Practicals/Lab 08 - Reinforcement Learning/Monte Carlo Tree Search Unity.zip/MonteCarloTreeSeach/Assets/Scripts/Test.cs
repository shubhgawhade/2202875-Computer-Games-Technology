﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using MCTS.Enum;
using MCTS.V2.Interfaces;
using MCTS.V2.UCT;
using MCTSTest;

public class Test : MonoBehaviour {

	[SerializeField] int coinNumber;
	[SerializeField] Text coinCounterText;
	[SerializeField] Text endGame;
	[SerializeField] GameObject button1;
	[SerializeField] GameObject button2;
	[SerializeField] GameObject button3;

	NimPlayer firstPlayer;
	IGameState nims;
	Action<string> printLine;
	bool running { get; set; }
	List<GameObject> listOfCoins;
	float timer = 1f;
	float resetTime = 1f;

	[SerializeField] GameObject coin;

	// Use this for initialization
	void Start () {
		running = false;
		printLine = s => Debug.Log(s);
		firstPlayer = new NimPlayer(1);
		nims = new NimState(coinNumber) as IGameState;
		listOfCoins = new List<GameObject>();

		if(coin != null)
		{
			for(int i = 0; i < coinNumber; i++)
			{
				listOfCoins.Add(Instantiate(coin, new Vector3(UnityEngine.Random.Range(-0.1f, 0.1f), (0.035f*(float)i) + 0.025f, UnityEngine.Random.Range(-0.1f, 0.1f)),Quaternion.identity));
			}
		}
		UpdateCoinCounter();
	}

	void FixedUpdate()
	{
		if(running &&timer > 0f)
		{
			timer -= Time.fixedDeltaTime;
		}
	}

	// Update is called once per frame
	void Update () {
		if(running && timer <= 0f)
		{
			if(!nims.GetMoves().Any())
			{
				endGame.text = "Player Wins";
				endGame.gameObject.SetActive(true);
			}
			else
			{
				//Debug.Log(nims.ToString());
				IMove move = SingleThreaded.ComputeSingleThreadedUCT(nims, 1000, true, printLine, 0.7F);
				Debug.Log("Move: " + move.Name);
				nims = move.DoMove();
				NimState nimS = (NimState)nims;

				for(int i = (listOfCoins.Count - 1); i >= nimS.GetChips(); i--)
				{
					Destroy(listOfCoins.ElementAt(i));
					listOfCoins.RemoveAt(i);
				}
				timer = resetTime;
				running = false;
				UpdateCoinCounter();
				SetButtonState(true);
				if(listOfCoins.Count == 0)
				{
					Debug.Log(nims.GetResult(firstPlayer).ToString());
					endGame.text = "AI Wins";
					endGame.gameObject.SetActive(true);
				}
			}
		}
	}

	public void RemoveCoins(int number)
	{
		for(int i = 0; i < number; i++)
		{
			Destroy(listOfCoins.ElementAt(listOfCoins.Count - 1));
			listOfCoins.RemoveAt(listOfCoins.Count - 1);
		}


		// Reset so it looks from where the player left the game world
		nims = new NimState(listOfCoins.Count) as IGameState;
		running = true;
		UpdateCoinCounter();
		SetButtonState(false);
	}

	public void StartGame()
	{
		running = true;
		GameObject.Find("Start").SetActive(false);
		UpdateCoinCounter();
	}

	private void SetButtonState(bool state)
	{
		button1.SetActive(state);
		button2.SetActive(state);
		button3.SetActive(state);
	}

	private void UpdateCoinCounter()
	{
		coinCounterText.text = listOfCoins.Count.ToString();
	}
}
