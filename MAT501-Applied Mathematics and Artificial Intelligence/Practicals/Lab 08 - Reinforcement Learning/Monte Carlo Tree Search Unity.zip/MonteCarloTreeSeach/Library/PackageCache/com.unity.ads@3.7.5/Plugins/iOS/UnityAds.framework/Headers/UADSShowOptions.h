#import <UnityAds/UADSBaseOptions.h>

@interface UADSShowOptions : UADSBaseOptions

@end
