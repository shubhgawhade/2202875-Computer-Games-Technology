#pragma once

/* Utility functions for the client and server */


// Print an error message and die.
void die(const char* message);

// Initialise the WinSock library.
void StartWinSock();
