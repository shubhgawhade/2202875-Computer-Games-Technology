#ifndef _BASE_ACTION_H_
#define _BASE_ACTION_H_

namespace MCTS
{
	class BaseAction
	{
		// Do nothing class that is a placeholder for more advanced actions
	};
}

#endif