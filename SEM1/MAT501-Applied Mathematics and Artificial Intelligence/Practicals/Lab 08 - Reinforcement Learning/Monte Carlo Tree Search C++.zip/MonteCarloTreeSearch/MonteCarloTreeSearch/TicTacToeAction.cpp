#include "TicTacToeAction.h"

TicTacToeAction::TicTacToeAction(int x, int y, BOARD_SQUARE_STATE playerMove) :
	x(x),
	y(y),
	playerMove(playerMove)
{
	// Do nothing here
}