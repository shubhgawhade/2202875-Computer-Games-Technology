#include <fl/Headers.h>

using namespace fl;

int main()
{
	Engine* engine = new Engine();

	delete engine;
	return 0;
}