#ifndef _NODE_STATUS_H_
#define _NODE_STATUS_H_

namespace BT
{
	enum class NodeStatus { NODE_IDLE, NODE_RUNNING, NODE_SUCCESS, NODE_FAILURE };
}

#endif